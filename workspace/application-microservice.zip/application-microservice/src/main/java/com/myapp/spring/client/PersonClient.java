package com.myapp.spring.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.myapp.spring.domain.Person;

@FeignClient("user-service")
public interface PersonClient {
	
	@GetMapping("users/{id}")
	EntityModel<Person> getById(@PathVariable("id")Integer id);
	
	@PostMapping("users")
	EntityModel<Person> saveNewPerson(Person person);
	// HighCohesion
	// Autonomous
	// Resilience
	
	

}
