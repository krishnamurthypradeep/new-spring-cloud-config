package com.myapp.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myapp.spring.client.PersonClient;
import com.myapp.spring.domain.Application;
import com.myapp.spring.domain.Person;
import com.myapp.spring.repository.ApplicationRepository;

import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class ApplicationServiceImpl implements ApplicationService {
	
	@Autowired
	private ApplicationRepository applicationRepository;
	
	@Autowired
	private PersonClient personClient;

	@Override
	@CircuitBreaker(name="applicationService",fallbackMethod = "buildFallbackApplicationList")
	@Bulkhead(name="applicationService",type = Bulkhead.Type.THREADPOOL,fallbackMethod ="buildFallbackApplicationList" )
	public List<Application> getApplicationByUsers() {
		// TODO Auto-generated method stub
		List<Application> list=applicationRepository.findAll();
		
		list.forEach(app->getPersonInfoUsingFeign(app));
		return list;
	}
	
	private void getPersonInfoUsingFeign(Application app)  {
		Person person=personClient.getById(app.getOwnerId()).getContent();
		app.setOwnerRole(person.getRole());
	}
	
	List<Application> buildFallbackApplicationList(Throwable t){
		
		List<Application> fallbackList = new ArrayList<>();
		Application application = new Application();
		application.setId(000);
		application.setDescription("Currently No Description Available");
		application.setName("No Name Available");
		application.setOwnerId(000);
		application.setOwnerRole("Roles could not be retrieved");
		fallbackList.add(application);
		
		
		return fallbackList;
	}
	

}
