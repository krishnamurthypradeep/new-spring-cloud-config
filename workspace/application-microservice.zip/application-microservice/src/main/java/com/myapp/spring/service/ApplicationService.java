package com.myapp.spring.service;

import java.util.List;

import com.myapp.spring.domain.Application;

public interface ApplicationService {

	List<Application> getApplicationByUsers();
}
