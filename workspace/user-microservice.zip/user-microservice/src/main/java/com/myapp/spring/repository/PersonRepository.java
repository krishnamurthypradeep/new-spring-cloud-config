package com.myapp.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.myapp.spring.domain.Person;

@RepositoryRestResource(path = "users")
public interface PersonRepository 
extends JpaRepository<Person, Integer> {

}
