package com.myapp.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
