package com.myapp.spring.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.myapp.spring.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
Optional<List<Product>> findByPriceGreaterThanEqual(Double price);

//@Query("select p from product p where p.releaseDate=?1")
@Query(value="select p from product p where p.releaseDate=:releaseDate")

//@Query(value="select *  from product p where p.release_date=:releaseDate",nativeQuery=true)
Product findByReleaseDate(@Param("releaseDate")String releaseDate);
}

// DISTINCT
// And
// Or
// Is,Equals
// Between
// LessThan
// After
// Before
// IsNull
// IsNotNull
// Like
// StartingWith
// EndingWith
// Containing
//OrderBy
//Not
//IgnoreCase

// Spring DATA (SQL & NOSQL Database)
